# JAVA ProJect 五子棋

#### 介绍
* 下棋
* 三三禁手
* 时间系统
* 人工智障

#### 代码框架规范
idea工程
**请使用idea开发**
**前端写在view里**

#### 如何使用git + idea开发代码
* [git bash安装](https://blog.csdn.net/weixin_41714277/article/details/79399270)
* ssh key 配置好
* git clone git@github.com:Cyberangel01/Gomoku.git
* idea打开工程，代码开发
* 开发完，git commit，之后 git push，都可以在idea VCS里完成


