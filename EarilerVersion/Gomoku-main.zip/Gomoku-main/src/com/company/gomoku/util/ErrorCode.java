package com.company.gomoku.util;

public class ErrorCode {
}
